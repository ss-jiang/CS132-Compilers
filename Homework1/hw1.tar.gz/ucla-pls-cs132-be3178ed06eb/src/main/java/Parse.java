public class Parse { 
    
    public static void main (String [] args) {
        System.out.println("Program parsed successfully");
    }

}

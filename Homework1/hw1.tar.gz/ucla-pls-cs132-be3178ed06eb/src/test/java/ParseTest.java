import org.junit.Test;
import static org.junit.Assert.*;

public class ParseTest {
    @Test public void testAppHasAGreeting() {
        Parse classUnderTest = new Parse();
        assertEquals(true, true);
    }
}
